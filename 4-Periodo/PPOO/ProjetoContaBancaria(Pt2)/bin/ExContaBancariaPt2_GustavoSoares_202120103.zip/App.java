public class App {
    public static void main(String[] args) throws Exception {
        CaixaEletronico caixa = new CaixaEletronico();
        // CaixaEletronicoComHashMap caixa = CaixaEletronicoComHashMap();

        caixa.executar();
    }
}
