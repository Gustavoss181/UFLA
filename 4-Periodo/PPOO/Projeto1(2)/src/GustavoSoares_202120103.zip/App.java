public class App {
    public static void main(String[] args) throws Exception {
        Principal principal = new Principal();

        principal.executar();
    }
}
