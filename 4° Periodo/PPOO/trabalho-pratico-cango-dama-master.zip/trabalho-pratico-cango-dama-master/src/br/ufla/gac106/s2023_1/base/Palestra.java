package br.ufla.gac106.s2023_1.base;

public class Palestra extends Atividade {
    private String nomePalestrante;
    private String tema;

    public Palestra(String titulo, String dataHora, Float precoIngresso, int maxIngresso, String nomePalestra, String tema){
        super(titulo, dataHora, precoIngresso, maxIngresso);
        this.nomePalestrante = nomePalestra;
        this.tema = tema;
    }

    //completa o detalhamento da atividade com as informações da palestra utilisando uma sobrescrita
    @Override
    public String detalhar() {
        String detalhamento = super.detalhar();
        
        detalhamento += "\nO nome do palestrante é " + nomePalestrante + 
            " e o tema sera sobre " + tema;

        return detalhamento;
    }
}
