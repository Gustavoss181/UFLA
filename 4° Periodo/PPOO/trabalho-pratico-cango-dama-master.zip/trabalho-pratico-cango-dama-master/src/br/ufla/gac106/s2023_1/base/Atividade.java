package br.ufla.gac106.s2023_1.base;

//foi feita uma classe abstrata pois ela não será instanciada em nenhum momento
public abstract class Atividade {
    private String titulo;
    private String dataHora; //dia e horario da atividade
    private Float precoIngresso;
    private int maxIngresso;

    public Atividade(String titulo, String dataHora, Float precoIngresso, int maxIngresso){
        this.titulo = titulo;
        this.dataHora = dataHora;
        this.precoIngresso = precoIngresso;
        this.maxIngresso = maxIngresso;
    }

    //o unico metodo get em atividade é o de titulo pois é pelo título que a atividade é encontrada nas outras classes
    public String getTitulo(){
        return titulo;
    }

    //faz o detalhamento da atividade que será realizada
    public String detalhar() {
        String detalhamento = "";

        detalhamento += titulo + " com data e horário " + dataHora +
            " pelo preço de " + precoIngresso + " e lotação maxima de " + maxIngresso; 

        return detalhamento;
    }
}
