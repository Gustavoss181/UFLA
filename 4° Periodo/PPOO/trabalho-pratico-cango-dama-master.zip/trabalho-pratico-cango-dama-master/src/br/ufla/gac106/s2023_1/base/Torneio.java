package br.ufla.gac106.s2023_1.base;

public class Torneio extends Atividade {
    private String genero;
    private String nomeJogo;

    public Torneio(String titulo, String dataHora, Float precoIngresso, int maxIngresso, String genero, String nomeJogo){
        super(titulo, dataHora, precoIngresso, maxIngresso);
        this.genero = genero;
        this.nomeJogo = nomeJogo;
    }

    //completa o detalhamento da atividade com as informações do torneio utilisando uma sobrescrita
    @Override
    public String detalhar() {
        String detalhamento = super.detalhar();
        
        detalhamento += "\nO genero do torneio é " + genero + 
            " e o nome do jogo é " + nomeJogo;

        return detalhamento;
    }
}
