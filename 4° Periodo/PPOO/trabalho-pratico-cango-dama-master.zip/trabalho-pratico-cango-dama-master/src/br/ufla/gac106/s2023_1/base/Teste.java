package br.ufla.gac106.s2023_1.base;

// Essa classe serve apenas para testar as funcionalidades do programa
public class Teste {
    public static void main(String[] args) {
        Administracao adm = new Administracao();

        // Centro
        adm.cadastrarCentro("Postinho", "Lavras");

        adm.listarCentros();

        adm.detalharCentro("Postinho");

        // Convencao
        boolean controle = adm.cadastrarConvencao("CCXP", "Anuncio de Jogos", 20, 30, "Postinho");
        if(controle)
            System.out.println("Convencao cadastrada");
        else
            System.out.println("Erro ao cadastrar");

        // Não é possível cadastrar duas convenções com o mesmo local
        controle = adm.cadastrarConvencao("Convencao2", "Encontro com empresas", 20, 30, "Postinho");
        if(controle)
            System.out.println("Convencao cadastrada");
        else
            System.out.println("Erro ao cadastrar");

        System.out.println(adm.listarConvencoes());

        System.out.println(adm.detalharConvencao("CCXP"));

        if(adm.removerConvencao("CCXP"))
            System.out.println("Convencao removida");
        else
            System.out.println("Erro ao remover");
        
        System.out.println(adm.listarConvencoes());

        System.out.println(adm.detalharConvencao("CCXP"));

        controle = adm.cadastrarConvencao("Convencao2", "Encontro com empresas", 20, 30, "Postinho");
        if(controle)
            System.out.println("Convencao cadastrada");
        else
            System.out.println("Erro ao cadastrar");
        
        System.out.println(adm.listarConvencoes());

        System.out.println(adm.detalharConvencao("Convencao2"));

        System.out.println(adm.detalharCentro("Postinho"));

        // Atividades
        adm.cadastrarAtividade("Convencao2", "Torneio de LOL", "Dia 25 as 10h", 500, 1000, null, null, "MOBA", "LOL");

        System.out.println(adm.listarAtividades("Convencao2"));

        System.out.println(adm.detalharAtividade("Convencao2", "Torneio de LOL"));

        if(adm.removerAtividade("Convencao2", "Torneio de LOL"))
            System.out.println("Atividade removida");
        else
            System.out.println("Erro ao remover");
        
        if(adm.removerCentro("Postinho"))
            System.out.println("Centro removido");
        else
            System.out.println("Erro ao remover");
        
        System.out.println(adm.listarCentros());
        
        System.out.println(adm.listarConvencoes());

        System.out.println(adm.detalharConvencao("Convencao2"));
        
    }
}
