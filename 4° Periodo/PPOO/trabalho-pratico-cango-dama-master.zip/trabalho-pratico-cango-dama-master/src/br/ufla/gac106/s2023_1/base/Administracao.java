package br.ufla.gac106.s2023_1.base;

import java.util.ArrayList;

public class Administracao {
    private ArrayList<ConvencaoJogos> convencoes;
    private ArrayList<CentroConvencao> centros;

    public Administracao() {
        convencoes = new ArrayList<>();
        centros = new ArrayList<>();
    }

    // metodos para simplificar busca, retornando o objeto caso encontre
    private ConvencaoJogos buscarConvencao(String nomeConv) {
        for (ConvencaoJogos convencao : convencoes)
            if (convencao.getNome().equals(nomeConv))
                return convencao;
        return null;
    }

    private CentroConvencao buscarCentro(String nomeCentro) {
        for (CentroConvencao centro : centros)
            if (centro.getNome().equals(nomeCentro))
                return centro;
        return null;
    }

    // Convenções
    public boolean cadastrarConvencao(String nomeConv, String tematica, int numExpo, int duracao, String nomeCentro) {
        CentroConvencao centro = buscarCentro(nomeCentro);

        if (centro == null)
            return false;

        if (centro.getConvencao() != null)
            return false;

        ConvencaoJogos novaConv = new ConvencaoJogos(nomeConv, tematica, numExpo, duracao, centro);

        convencoes.add(novaConv);
        centro.setConvencao(novaConv);

        return true;
    }

    public String listarConvencoes() {
        if(convencoes.size() == 0)
            return null;
        
        String listagemConv = "Convencoes:";

        for (ConvencaoJogos convencao : convencoes)
            listagemConv += "\n - " + convencao.getNome();

        return listagemConv;
    }

    public String detalharConvencao(String nomeConvencao) {
        ConvencaoJogos convencao = buscarConvencao(nomeConvencao);

        if (convencao != null)
            return convencao.detalhar();

        return null;
    }

    public boolean removerConvencao(String nomeConvencao) {
        ConvencaoJogos convencao = buscarConvencao(nomeConvencao);

        if (convencao == null)
            return false;

        convencao.getCentroConvencao().setConvencao(null);

        return convencoes.remove(convencao);
    }
    // Parte dos Locais

    public void cadastrarCentro(String nomeCentro, String cidadeDoCentro) {
        CentroConvencao novoLocal = new CentroConvencao(nomeCentro, cidadeDoCentro);

        centros.add(novoLocal);
    }

    public String listarCentros() {
        if(centros.size() == 0)
            return null;
        
        String listagemCentro = "Centros:";
        for (CentroConvencao centro : centros)
            listagemCentro += "\n - " + centro.getNome();

        return listagemCentro;
    }

    public String detalharCentro(String nomeCentro) {
        CentroConvencao centro = buscarCentro(nomeCentro);

        if (centro != null)
            return centro.detalhar();

        return null;
    }

    // Se o centro for removido a convenção também será entretanto isso não é
    // verdade no sentido contrário
    public boolean removerCentro(String nomeCentro) {
        CentroConvencao centro = buscarCentro(nomeCentro);

        if (centro == null)
            return false;

        convencoes.remove(centro.getConvencao());

        return centros.remove(centro);
    }

    // Parte das Atividades (ponte)
    public boolean cadastrarAtividade(String nomeConvencao, String titulo, String dataHora, float precoIngresso,
            int maxIngressos, String nomePalestrante, String tema, String genero, String nomeJogo) {
        ConvencaoJogos convencao = buscarConvencao(nomeConvencao);
        if (convencao != null)
            return convencao.cadastrarAtividade(titulo, dataHora, precoIngresso, maxIngressos, nomePalestrante, tema,
                    genero, nomeJogo);
        return false;
    }

    public String listarAtividades(String nomeConvencao) {
        ConvencaoJogos convencao = buscarConvencao(nomeConvencao);
        if (convencao != null)
            return convencao.listarAtividades();
        return null;
    }

    public String detalharAtividade(String nomeConvencao, String titulo) {
        ConvencaoJogos convencao = buscarConvencao(nomeConvencao);
        if (convencao != null)
            return convencao.detalharAtividade(titulo);
        return null;
    }

    public boolean removerAtividade(String nomeConvencao, String titulo) {
        ConvencaoJogos convencao = buscarConvencao(nomeConvencao);
        if (convencao != null)
            return convencao.removerAtividade(titulo);
        return false;
    }

}