package br.ufla.gac106.s2023_1.base;

import java.util.ArrayList;

public class ConvencaoJogos {

    private String nome;
    private String tematica;
    private int nExposicoes;
    private int duracao;
    private ArrayList<Atividade> atividades;
    private CentroConvencao local; // associa o lugar a uma convençao

    public ConvencaoJogos(String nome, String tematica, int nExposicoes, int duracao, CentroConvencao local){
        this.nome = nome;
        this.tematica = tematica;
        this.nExposicoes = nExposicoes;
        this.duracao = duracao;
        atividades = new ArrayList<>();
        this.local = local;
    }

    public String getNome(){
        return nome;
    }

    public String detalhar(){
        
        String detalhar = "";

        detalhar += "A convencao " + nome + " cujo a tematica é " + 
            tematica + " com o seguinte numero de expositores " + nExposicoes +  " e com a duraçao de " + duracao;
        
        detalhar += "\nOcorrera no " +  local.getNome();

        if(atividades.size() == 0)
            return detalhar;

        detalhar += "\nContara com as seguintes Atividades:";
        for(Atividade atividade : atividades){
            detalhar += "\n - " + atividade.getTitulo();
        }

        return detalhar;
    }
    // cadastra a atividade avaliando parametros de acordo com o construtor de cada atividade
    public boolean cadastrarAtividade(String titulo, String dataHora, float precoIngresso, int maxIngressos, String nomePalestrante, String tema, String genero, String nomeJogo){
        
        if(nomePalestrante != null && tema != null){
            atividades.add(new Palestra(titulo, dataHora, precoIngresso, maxIngressos, nomePalestrante, tema));
            return true;
        }else if(genero != null && nomeJogo != null){
            atividades.add(new Torneio(titulo, dataHora, precoIngresso, maxIngressos, genero, nomeJogo));
            return true;
        }
        return false;
    }

    public String listarAtividades(){
        
        if(atividades.size() == 0)
            return null;
        
        String listar = "As atividades sao:";

        for(Atividade atividade : atividades)
            listar += "\n - " + atividade.getTitulo();

        return listar;

    }

    public String detalharAtividade(String titulo){
        
        String detalhar = "";

        for(Atividade atividade : atividades){
            if(atividade.getTitulo().equals(titulo)){
                detalhar = atividade.detalhar();
                return detalhar;
            }
        }

        return null;
    }
    public boolean removerAtividade(String titulo){

        for (int i = 0; i < atividades.size(); i++) {
            if (atividades.get(i).getTitulo().equals(titulo)) {
                atividades.remove(i);
                return true;
            }
        }
        return false;
    }

    public CentroConvencao getCentroConvencao(){
        return local;
    }

}