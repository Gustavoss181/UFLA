package br.ufla.gac106.s2023_1.base;

public class CentroConvencao{
    private String nome;
    private String cidade;
    private ConvencaoJogos convencao; // associa uma convenção a um lugar

    public CentroConvencao(String nome, String cidade){
        this.nome = nome;
        this.cidade = cidade;
    }

    public String detalhar(){
        String descricao = "";
        if(convencao != null){
            descricao += "Esta ocorrendo a convencao " + convencao.getNome() + " no ";
        }
        descricao += "Centro de Convencao " + nome + " localizado na cidade de " + cidade;
        return descricao;
    }

    public String getNome(){
        return nome;
    }

    public void setConvencao(ConvencaoJogos convencao){ // fazer a associação da Convenção com o Centro (null caso a convenção tenha sido deletada)
        this.convencao = convencao;
    }

    public ConvencaoJogos getConvencao() {
        return convencao;
    }
}